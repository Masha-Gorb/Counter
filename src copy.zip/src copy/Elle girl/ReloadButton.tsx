import React from 'react';

export const ReloadButton = () => {
    return (
            <button onClick={window.location.reload}>Reload test!</button>
    )
}